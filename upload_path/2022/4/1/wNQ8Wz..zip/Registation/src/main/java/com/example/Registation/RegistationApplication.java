package com.example.Registation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegistationApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistationApplication.class, args);
	}

}
